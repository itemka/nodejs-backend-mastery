Outside the export folder.
